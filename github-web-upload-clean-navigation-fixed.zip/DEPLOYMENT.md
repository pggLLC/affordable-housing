# Deployment Guide (Direct Upload to GitHub Pages)

This repo is prepared for **GitHub Pages** with the site served from the repository **root**.

## 1) Create a new GitHub repository
1. GitHub → **New repository**
2. Name it (example): `affordable-housing`
3. Visibility: Public (recommended for Pages)
4. Create repository (no need to add a README—this package already includes one)

## 2) Upload this package to GitHub
### Option A — Web upload
1. In the new repo: **Add file → Upload files**
2. Upload **all files and folders** (including `.github/`, `css/`, `js/`, `data/`, all `*.html`)
3. Commit to `main`

### Option B — Git
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin <YOUR_REPO_URL>
git push -u origin main
```

## 3) Enable GitHub Pages
1. Repo → **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: `main`
4. Folder: `/(root)`
5. Save

GitHub will display your Pages URL (e.g., `https://<user>.github.io/<repo>/`).

## 4) Configure GitHub Actions secret (required)
The FRED refresh workflow needs `FRED_API_KEY`.

1. Repo → **Settings → Secrets and variables → Actions**
2. **New repository secret**
3. Name: `FRED_API_KEY`
4. Value: your FRED API key
5. Save

## 5) Run the workflow once (recommended)
1. Repo → **Actions**
2. Select **Fetch FRED Data**
3. Click **Run workflow**

After it finishes, verify `data/fred-data.json` updated in the commit history.

## 6) Census API keys (optional)
If any pages use Census endpoints heavily, you may want a key for higher rate limits.

- Copy `js/config.js.template` → `js/config.js`
- Add `CENSUS_API_KEY`
- **Do not commit** `js/config.js` (it’s in `.gitignore`)

## 7) Common issues
### Workflow fails with “Missing FRED_API_KEY”
Add the secret described in step 4.

### Pages loads but some charts are empty
- Confirm `data/fred-data.json` exists in the repo and has a recent `"updated"` timestamp
- Re-run the workflow manually

---

_Last updated: 2026-02-20_
