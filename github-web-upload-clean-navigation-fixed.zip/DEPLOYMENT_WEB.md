# Web Upload Deployment Guide (GitHub Pages + Secrets + Actions)

This guide is for deploying the site **using only the GitHub web interface** (no command line).  
It also covers adding **FRED** and **Census** API keys as **GitHub Secrets** and ensuring **hidden files** like `.github/` are uploaded.

---

## 1) Create a new GitHub repository
1. Go to GitHub → **New repository**
2. Name it (example): `affordable-housing`
3. Choose **Public** (recommended for GitHub Pages)
4. Click **Create repository**

---

## 2) Upload the ZIP contents (including hidden `.github/` folder)
### Important note about hidden folders
GitHub Actions workflows must be in:  
`/.github/workflows/`

If `.github/` is missing, the workflow **will not run**.

### Upload steps (web)
1. Open your new repository on GitHub
2. Click **Add file → Upload files**
3. **Drag and drop the entire contents** of this ZIP into the upload area:
   - You should see folders like `css/`, `js/`, `data/`, `docs/`, and also **`.github/`**
4. Scroll the file list and confirm:
   - `.github/workflows/fetch-fred-data.yml` is visible
5. At the bottom, choose:
   - Commit message: `Initial site upload`
   - Commit directly to `main`
6. Click **Commit changes**

✅ After commit, verify in the repo root that `.github/` exists.

---

## 3) Turn on GitHub Pages
1. Repo → **Settings**
2. Left menu → **Pages**
3. Under **Build and deployment**:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/(root)`
4. Click **Save**

GitHub will show your site URL like:
`https://<username>.github.io/<repo>/`

---

## 4) Add API keys as GitHub Secrets (FRED + Census)
1. Repo → **Settings**
2. Left menu → **Secrets and variables → Actions**
3. Click **New repository secret**
4. Add these secrets:

### Required for the workflow
- **Name:** `FRED_API_KEY`
- **Value:** your FRED API key

### Recommended for Census integrations
- **Name:** `CENSUS_API_KEY`
- **Value:** your Census API key

> Names are **case-sensitive**.

---

## 5) Run the workflow once (web) to generate/update `data/fred-data.json`
1. Repo → **Actions**
2. Click **Fetch FRED Data**
3. Click **Run workflow** → **Run workflow**

When it finishes successfully:
- `data/fred-data.json` will be updated
- A commit will appear in your repo history

### If it fails
- Confirm `FRED_API_KEY` exists: Settings → Secrets and variables → Actions
- Confirm `.github/workflows/fetch-fred-data.yml` exists in your repo

---


## Census build workflow (recommended)
- This repo includes a second workflow: **Fetch Census ACS Data** (`.github/workflows/fetch-census-acs.yml`).
- It writes: `data/census-acs-state.json` (state-level ACS 5-year indicators).
- Add the secret **CENSUS_API_KEY** (Settings → Secrets and variables → Actions), then run the workflow once from the Actions tab.

## 6) Census key usage (two options)
### Option A (recommended): keep Census calls out of the browser
Best practice is to fetch Census data in Actions (like FRED) and write `data/census-data.json`.
Your pages read from `data/` files so keys are not exposed.

If you want this, tell ChatGPT: **"Add Census build workflow"** and we will add a second workflow.

### Option B (client-side Census calls)
If some pages call Census directly from the browser, a key in client-side JS can be visible on public sites.
If you still want client-side Census:
- Use `js/config.local.js` locally (do not commit), or
- Create `js/config.js` from `js/config.js.template` and commit it (not recommended for public repos).

---

## 7) Confirm everything works
Open your Pages URL and verify:
- Home page loads
- Navigation works
- Charts load
- No console errors about missing files
- `data/fred-data.json` updates after running the workflow

---

## Quick checklist
- [ ] `.github/workflows/fetch-fred-data.yml` present
- [ ] Pages enabled (main / root)
- [ ] Secrets set: `FRED_API_KEY` (+ `CENSUS_API_KEY` optional)
- [ ] Workflow ran at least once
- [ ] Site loads at GitHub Pages URL

---

**Package build date:** 2026-02-20
